gLiveStreamer is a GTK+ frontend for livestreamer: http://livestreamer.tanuki.se/

Installation
=============
Install dependencies:
rtmpdump
python-setuptools
mono

Install Livestreamer:
git clone git://github.com/chrippa/livestreamer.git
cd livestreamer
python setup.py install

Run gLiveStreamer:
mono gLiveStreamer.exe